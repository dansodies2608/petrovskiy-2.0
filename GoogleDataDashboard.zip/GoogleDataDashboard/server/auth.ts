import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "your-secret-key-here",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: 'email' },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user || !(await comparePasswords(password, user.password))) {
            return done(null, false);
          }
          return done(null, user);
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Check if admin exists endpoint
  app.get("/api/admin-exists", async (req, res) => {
    try {
      const hasAdmin = await storage.hasAdminUser();
      res.json({ hasAdmin });
    } catch (error) {
      res.status(500).json({ error: "Ошибка проверки администратора" });
    }
  });

  // Register first admin (only if no admin exists)
  app.post("/api/register-admin", async (req, res) => {
    try {
      const hasAdmin = await storage.hasAdminUser();
      if (hasAdmin) {
        return res.status(400).json({ error: "Администратор уже существует" });
      }

      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email и пароль обязательны" });
      }

      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Пользователь с таким email уже существует" });
      }

      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        role: "admin"
      });

      req.login(user, (err) => {
        if (err) return res.status(500).json({ error: "Ошибка входа" });
        res.status(201).json({ id: user.id, email: user.email, role: user.role });
      });
    } catch (error) {
      res.status(500).json({ error: "Ошибка создания администратора" });
    }
  });

  // Login
  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json({ 
      id: req.user!.id, 
      email: req.user!.email, 
      role: req.user!.role 
    });
  });

  // Logout
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json({ 
      id: req.user!.id, 
      email: req.user!.email, 
      role: req.user!.role 
    });
  });

  // Admin-only routes
  function requireAdmin(req: any, res: any, next: any) {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.sendStatus(403);
    }
    next();
  }

  // Get all users (admin only)
  app.get("/api/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const safeUsers = users.map(({ password, ...user }) => user);
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ error: "Ошибка получения пользователей" });
    }
  });

  // Create user (admin only)
  app.post("/api/users", requireAdmin, async (req, res) => {
    try {
      const { email, password, role } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email и пароль обязательны" });
      }

      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Пользователь с таким email уже существует" });
      }

      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        role: role || "user"
      });

      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "Ошибка создания пользователя" });
    }
  });

  // Update user (admin only)
  app.put("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { email, password, role } = req.body;
      
      const updates: any = {};
      if (email) updates.email = email;
      if (password) updates.password = await hashPassword(password);
      if (role) updates.role = role;

      const user = await storage.updateUser(userId, updates);
      if (!user) {
        return res.status(404).json({ error: "Пользователь не найден" });
      }

      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "Ошибка обновления пользователя" });
    }
  });

  // Delete user (admin only)
  app.delete("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Prevent admin from deleting themselves
      if (req.user!.id === userId) {
        return res.status(400).json({ error: "Нельзя удалить свой аккаунт" });
      }

      const success = await storage.deleteUser(userId);
      if (!success) {
        return res.status(404).json({ error: "Пользователь не найден" });
      }

      res.sendStatus(200);
    } catch (error) {
      res.status(500).json({ error: "Ошибка удаления пользователя" });
    }
  });
}