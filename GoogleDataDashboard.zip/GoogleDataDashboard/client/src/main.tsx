import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// SEO Meta tags
document.title = "Автомобильная Аналитика - Панель управления";

const metaDescription = document.createElement('meta');
metaDescription.name = 'description';
metaDescription.content = 'Современная панель управления для анализа продаж автомобилей, сервисных показателей и финансовых данных';
document.head.appendChild(metaDescription);

const ogTitle = document.createElement('meta');
ogTitle.setAttribute('property', 'og:title');
ogTitle.content = 'Автомобильная Аналитика - Панель управления';
document.head.appendChild(ogTitle);

const ogDescription = document.createElement('meta');
ogDescription.setAttribute('property', 'og:description');
ogDescription.content = 'Анализ продаж новых и подержанных автомобилей, контроль сервисных показателей и мониторинг финансового состояния';
document.head.appendChild(ogDescription);

createRoot(document.getElementById("root")!).render(<App />);
