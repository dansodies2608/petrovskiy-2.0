export interface DashboardData {
  status: string;
  selectedMonth: number;
  selectedYear: number;
  currentMonth: string;
  newCars?: {
    currentData: SalesItem[];
    prevData: SalesItem[];
    prevYearData: SalesItem[];
    plans: Record<string, PlanData>;
  };
  usedCars?: {
    currentData: SalesItem[];
    prevData: SalesItem[];
    prevYearData: SalesItem[];
    plans: Record<string, PlanData>;
    aspData?: Record<string, ASPData>;
  };
  serviceData?: Record<string, ServiceData>;
  mkcData?: Record<string, MKCData>;
  balanceData?: BalanceData;
}

export interface SalesItem {
  salesPoint: string;
  brand?: string;
  soldCount?: number;
  jok?: number;
}

export interface PlanData {
  total: number;
}

export interface ASPData {
  plan: number;
  fact: number;
  sum: number;
}

export interface ServiceData {
  nh: {
    plan: number;
    fact: number;
    deviation: number;
  };
  gm1: {
    plan: number;
    fact: number;
    deviation: number;
  };
}

export interface MKCData {
  nh: {
    plan: number;
    fact: number;
    deviation: number;
  };
  gm1: {
    plan: number;
    fact: number;
    deviation: number;
  };
}

export interface BalanceData {
  assets: {
    cash: number;
    inventory: number;
    newCars: number;
    usedCars: number;
    parts: number;
    receivables: number;
    total: number;
  };
  liabilities: {
    creditLines: number;
    factoring: number;
    otherCredits: number;
    total: number;
  };
  netAssets: number;
}

export interface ProcessedSalesData {
  current: {
    brands: Record<string, { count: number; jok: number }>;
    total: number;
    jok: number;
  };
  prevMonth: {
    brands: Record<string, { count: number; jok: number }>;
    total: number;
    jok: number;
  };
  prevYear: {
    brands: Record<string, { count: number; jok: number }>;
    total: number;
    jok: number;
  };
  plan: PlanData;
}

export interface LocationMetrics {
  plan: number;
  fact: number;
  deviation: number;
  totalJOK: number;
  jokPerUnit: number;
  dynamics: {
    current: number;
    previous: number;
    previousYear: number;
  };
}

export type TabType = 'new-cars' | 'used-cars' | 'service' | 'mkc' | 'balance';
