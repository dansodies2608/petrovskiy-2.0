import type { SalesItem, ProcessedSalesData, PlanData, LocationMetrics } from '@/types/dashboard';

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('ru-RU').format(num);
}

export function formatCurrency(amount: number, withSymbol: boolean = true): string {
  if (isNaN(amount) || amount === 0) {
    return withSymbol ? 'не число ₽' : 'не число';
  }

  if (withSymbol) {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  } else {
    return new Intl.NumberFormat('ru-RU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount) + ' ₽';
  }
}

export function calculateDeviation(plan: number, fact: number): number {
  if (!plan || plan === 0) return 0;
  return ((fact - plan) / plan) * 100;
}

export function formatDeviation(deviation: number): string {
  const sign = deviation >= 0 ? '+' : '';
  return `${sign}${deviation.toFixed(1)}%`;
}

export function getDeviationClass(deviation: number): string {
  if (deviation >= 0) {
    return "bg-green-100 text-green-800 border-green-200";
  } else {
    return "bg-red-100 text-red-800 border-red-200";
  }
}

export function sortLocationsByPriority(locations: Record<string, any>): [string, any][] {
  const priorityOrder = ['Софийская', 'Руставели', 'Каширка'];

  return Object.entries(locations).sort(([a], [b]) => {
    const aIndex = priorityOrder.indexOf(a);
    const bIndex = priorityOrder.indexOf(b);

    // If both locations are in priority list, sort by priority
    if (aIndex !== -1 && bIndex !== -1) {
      return aIndex - bIndex;
    }

    // If only one is in priority list, prioritize it
    if (aIndex !== -1) return -1;
    if (bIndex !== -1) return 1;

    // If neither is in priority list, sort alphabetically
    return a.localeCompare(b);
  });
}

export function processSalesData(
  currentData: SalesItem[],
  prevData: SalesItem[],
  prevYearData: SalesItem[],
  plans: Record<string, PlanData>
): Record<string, ProcessedSalesData> {
  const result: Record<string, ProcessedSalesData> = {};
  const allPoints = new Set<string>();

  // Collect all sales points
  [currentData, prevData, prevYearData].forEach(data => {
    data.forEach(item => {
      if (item && item.salesPoint) {
        const point = item.salesPoint === "Каширское ш." ? "Каширка" : item.salesPoint;
        allPoints.add(point);
      }
    });
  });

  // Fixed order of points
  const orderedPoints = ['Софийская', 'Руставели', 'Каширка'];

  // Add other points (excluding already specified), preserving original order
  allPoints.forEach(point => {
    if (!orderedPoints.includes(point)) {
      orderedPoints.push(point);
    }
  });

  // Process each sales point
  allPoints.forEach(point => {
    const currentMonth = currentData.filter(item => {
      const salesPoint = item.salesPoint === "Каширское ш." ? "Каширка" : item.salesPoint;
      return salesPoint === point;
    });

    const prevMonth = prevData.filter(item => {
      const salesPoint = item.salesPoint === "Каширское ш." ? "Каширка" : item.salesPoint;
      return salesPoint === point;
    });

    const prevYear = prevYearData.filter(item => {
      const salesPoint = item.salesPoint === "Каширское ш." ? "Каширка" : item.salesPoint;
      return salesPoint === point;
    });

    result[point] = {
      current: aggregateData(currentMonth),
      prevMonth: aggregateData(prevMonth),
      prevYear: aggregateData(prevYear),
      plan: plans[point] || { total: 0 }
    };
  });

  return result;
}

function aggregateData(data: SalesItem[]) {
  const brands: Record<string, { count: number; jok: number }> = {};
  let totalCount = 0;
  let totalJOK = 0;

  data.forEach(item => {
    if (item && item.brand && typeof item.soldCount === 'number') {
      const brand = item.brand;
      const soldCount = item.soldCount;
      const jok = typeof item.jok === 'number' ? item.jok : 0;

      if (!brands[brand]) {
        brands[brand] = { count: 0, jok: 0 };
      }

      brands[brand].count += soldCount;
      brands[brand].jok += jok;
      totalCount += soldCount;
      totalJOK += jok;
    }
  });

  return {
    brands,
    total: totalCount,
    jok: totalJOK
  };
}

export function processPeriodData(data: SalesItem[], point: string) {
  const filtered = data.filter((item) => {
    const salesPoint = item.salesPoint === "Каширское ш." ? "Каширка" : item.salesPoint;
    return salesPoint === point && (item.soldCount || item.jok);
  });

  const result = {
    brands: {} as Record<string, { count: number; jok: number }>,
    total: 0,
    jok: 0,
  };

  filtered.forEach((item) => {
    const brand = item.brand || "Другие";
    const soldCount = item.soldCount || 0;
    const jok = item.jok || 0;

    result.brands[brand] = result.brands[brand] || { count: 0, jok: 0 };
    result.brands[brand].count += soldCount;
    result.brands[brand].jok += jok;
    result.total += soldCount;
    result.jok += jok;
  });

  return result;
}

export function calculateLocationMetrics(pointData: ProcessedSalesData): LocationMetrics {
  const { current, prevMonth, prevYear, plan } = pointData;

  const planValue = plan?.total || 0;
  const factValue = current?.total || 0;
  const deviation = calculateDeviation(planValue, factValue);

  return {
    plan: planValue,
    fact: factValue,
    deviation: deviation,
    totalJOK: current?.jok || 0,
    jokPerUnit: factValue > 0 ? (current?.jok || 0) / factValue : 0,
    dynamics: {
      current: factValue,
      previous: prevMonth?.total || 0,
      previousYear: prevYear?.total || 0
    }
  };
}

export function calculateAggregatedASPData(aspData: Record<string, any>) {
  const result: Record<string, any> = {};

  const dealTypes = ['Выкуп', 'Trade-In', 'Внутренний Trade-In', 'Комиссия'];

  dealTypes.forEach(type => {
    let planValue = 0;
    let totalFact = 0;
    let totalSum = 0;

    // Get plan from first location (since it's the same for all) and aggregate fact/sum
    const locations = Object.values(aspData);
    if (locations.length > 0) {
      const firstLocation = locations[0] as any;
      if (firstLocation[type]) {
        planValue = firstLocation[type].plan || 0;
      }
    }

    // Aggregate fact and sum across all points for each deal type
    Object.values(aspData).forEach((pointData: any) => {
      if (pointData[type]) {
        totalFact += pointData[type].fact || 0;
        totalSum += pointData[type].sum || 0;
      }
    });

    if (planValue > 0 || totalFact > 0) {
      result[type] = {
        plan: planValue,
        fact: totalFact,
        sum: totalSum
      };
    }
  });

  return result;
}

export function getMonthName(month: number): string {
  const months = [
    'ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ',
    'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ'
  ];
  return months[month - 1] || '';
}