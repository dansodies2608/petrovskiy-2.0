const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzmiq2x3zkNetsY9DPJym3tVSPkuC4YY8lWa7w270PILhW4XgaaLAjAb0AkHk-pr2GbVw/exec";
const SECRET_KEY = "b3821cce5703d067b14f4e63c9e65fd86ce24f5de0438f8a69a006167f2899ca";

export async function fetchDashboardData(month: number, year: number) {
  try {
    // Validate date selection
    const today = new Date();
    if (year > today.getFullYear() || 
        (year === today.getFullYear() && month > today.getMonth() + 1)) {
      throw new Error('Нельзя выбрать будущую дату');
    }

    // Fetch data from multiple endpoints
    const [salesResponse, serviceResponse, mkcResponse, balanceResponse] = await Promise.all([
      fetch(`${SCRIPT_URL}?key=${SECRET_KEY}&month=${month}&year=${year}&type=sales`),
      fetch(`${SCRIPT_URL}?key=${SECRET_KEY}&month=${month}&year=${year}&type=service`),
      fetch(`${SCRIPT_URL}?key=${SECRET_KEY}&month=${month}&year=${year}&type=mkc`),
      fetch(`${SCRIPT_URL}?key=${SECRET_KEY}&type=balance`)
    ]);

    if (!salesResponse.ok) {
      throw new Error(`HTTP Error: ${salesResponse.status}`);
    }

    const [salesData, serviceData, mkcData, balanceData] = await Promise.all([
      salesResponse.json(),
      serviceResponse.json(),
      mkcResponse.json(),
      balanceResponse.json()
    ]);

    if (salesData.status !== 'success') {
      throw new Error(salesData.message || 'Ошибка загрузки данных');
    }

    // Combine all data
    return {
      ...salesData,
      serviceData: serviceData.data,
      mkcData: mkcData.data,
      balanceData: balanceData.data || balanceData
    };
  } catch (error) {
    console.error('Data loading error:', error);
    throw error;
  }
}
