import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Coins, CreditCard, Scale } from 'lucide-react';
import { formatCurrency } from '@/lib/dashboard-utils';
import type { DashboardData } from '@/types/dashboard';

interface BalanceTabProps {
  data: DashboardData;
}

export function BalanceTab({ data }: BalanceTabProps) {
  if (!data.balanceData) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Нет данных для отображения</p>
      </div>
    );
  }

  const balance = data.balanceData;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Assets Card */}
      <Card className="card-hover border border-gray-100">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
            <Coins className="text-success mr-3" size={20} />
            Активы
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Денежные средства</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.assets.cash)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Складские остатки</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.assets.inventory)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Новые автомобили</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.assets.newCars)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Автомобили с пробегом</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.assets.usedCars)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Запчасти</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.assets.parts)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Дебиторская задолженность</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.assets.receivables)}</span>
            </div>
            <div className="flex justify-between items-center py-3 bg-success/10 rounded-lg px-3 font-semibold">
              <span className="text-success">Итого активы</span>
              <span className="text-success">{formatCurrency(balance.assets.total)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Liabilities Card */}
      <Card className="card-hover border border-gray-100">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
            <CreditCard className="text-error mr-3" size={20} />
            Пассивы
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Кредитные линии</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.liabilities.creditLines)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Факторинг</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.liabilities.factoring)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Прочие кредиты и займы</span>
              <span className="font-semibold text-gray-900">{formatCurrency(balance.liabilities.otherCredits)}</span>
            </div>
            <div className="flex justify-between items-center py-3 bg-error/10 rounded-lg px-3 font-semibold">
              <span className="text-error">Итого пассивы</span>
              <span className="text-error">{formatCurrency(balance.liabilities.total)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Net Assets Card */}
      <Card className="bg-gradient-to-br from-primary to-primary/80 text-white card-hover border border-gray-100">
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center">
            <Scale className="mr-3" size={20} />
            Чистые активы
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <div className="text-4xl font-bold mb-2">{formatCurrency(balance.netAssets)}</div>
            <div className="text-sm opacity-90">Активы - Пассивы</div>
          </div>
          <div className="mt-6 p-4 bg-white/20 rounded-lg">
            <div className="text-sm opacity-90 mb-1">Финансовое состояние</div>
            <div className="font-semibold">
              {balance.netAssets >= 0 ? 'Положительное' : 'Отрицательное'}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
