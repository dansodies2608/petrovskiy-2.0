import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart3 } from 'lucide-react';
import { formatNumber, formatDeviation, getDeviationClass } from '@/lib/dashboard-utils';
import type { DashboardData } from '@/types/dashboard';

interface MKCTabProps {
  data: DashboardData;
}

export function MKCTab({ data }: MKCTabProps) {
  if (!data.mkcData) {
    return (
      <Card className="border border-gray-100">
        <CardContent className="text-center py-12">
          <BarChart3 className="mx-auto h-16 w-16 text-gray-300 mb-4" />
          <p className="text-gray-500">Нет данных для отображения</p>
          <p className="text-sm text-gray-400 mt-2">МКЦ данные будут загружены при наличии</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {Object.entries(data.mkcData).map(([pointName, pointData]) => {
        // Only show points with valid plan data
        if (pointData.nh.plan <= 0 && pointData.gm1.plan <= 0) {
          return null;
        }

        return (
          <Card key={pointName} className="card-hover border border-gray-100">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900">
                {pointName}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Нормо-часы */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Нормо-часы</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">План/Факт</span>
                    <span className="font-semibold text-gray-900">
                      {formatNumber(pointData.nh.plan)} / {formatNumber(pointData.nh.fact)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Отклонение</span>
                    <Badge 
                      variant={pointData.nh.deviation >= 0 ? "default" : "destructive"}
                      className={`text-xs ${getDeviationClass(pointData.nh.deviation)}`}
                    >
                      {formatDeviation(pointData.nh.deviation)}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* GM-1 */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-sm font-medium text-gray-700 mb-3">GM-1</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">План/Факт</span>
                    <span className="font-semibold text-gray-900">
                      {formatNumber(pointData.gm1.plan)} / {formatNumber(pointData.gm1.fact)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Отклонение</span>
                    <Badge 
                      variant={pointData.gm1.deviation >= 0 ? "default" : "destructive"}
                      className={`text-xs ${getDeviationClass(pointData.gm1.deviation)}`}
                    >
                      {formatDeviation(pointData.gm1.deviation)}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
