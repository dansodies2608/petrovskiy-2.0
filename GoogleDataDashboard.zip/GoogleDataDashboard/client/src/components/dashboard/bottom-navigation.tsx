import { Car, History, Wrench, TrendingUp, Scale } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { TabType } from '@/types/dashboard';

interface BottomNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const tabs = [
  { id: 'new-cars' as TabType, label: 'НА', icon: Car },
  { id: 'used-cars' as TabType, label: 'АСП', icon: History },
  { id: 'service' as TabType, label: 'СТС', icon: Wrench },
  { id: 'mkc' as TabType, label: 'МКЦ', icon: TrendingUp },
  { id: 'balance' as TabType, label: 'БАЛАНС', icon: Scale },
];

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-around">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={cn(
                  "tab-btn flex flex-col items-center py-3 px-4 text-xs",
                  isActive ? "text-primary" : "text-gray-500"
                )}
              >
                <Icon className="text-lg mb-1" size={20} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
