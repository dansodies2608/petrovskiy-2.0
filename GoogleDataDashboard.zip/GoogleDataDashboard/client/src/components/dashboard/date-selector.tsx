import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';

interface DateSelectorProps {
  selectedMonth: number;
  selectedYear: number;
  onDateChange: (month: number, year: number) => void;
  isLoading: boolean;
}

export function DateSelector({ selectedMonth, selectedYear, onDateChange, isLoading }: DateSelectorProps) {
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 3 }, (_, i) => currentYear - 2 + i);
  
  const months = [
    { value: 1, label: 'Январь' },
    { value: 2, label: 'Февраль' },
    { value: 3, label: 'Март' },
    { value: 4, label: 'Апрель' },
    { value: 5, label: 'Май' },
    { value: 6, label: 'Июнь' },
    { value: 7, label: 'Июль' },
    { value: 8, label: 'Август' },
    { value: 9, label: 'Сентябрь' },
    { value: 10, label: 'Октябрь' },
    { value: 11, label: 'Ноябрь' },
    { value: 12, label: 'Декабрь' }
  ];

  const handleApply = () => {
    onDateChange(selectedMonth, selectedYear);
  };

  return (
    <div className="flex items-center space-x-3">
      <div className="flex items-center space-x-2 bg-gray-50 rounded-lg p-2">
        <Select 
          value={selectedMonth.toString()} 
          onValueChange={(value) => onDateChange(parseInt(value), selectedYear)}
        >
          <SelectTrigger className="w-auto border-none bg-transparent text-sm font-medium text-gray-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {months.map(month => (
              <SelectItem key={month.value} value={month.value.toString()}>
                {month.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select 
          value={selectedYear.toString()} 
          onValueChange={(value) => onDateChange(selectedMonth, parseInt(value))}
        >
          <SelectTrigger className="w-auto border-none bg-transparent text-sm font-medium text-gray-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {years.map(year => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <Button 
        onClick={handleApply}
        disabled={isLoading}
        className="bg-primary hover:bg-primary/90 text-white px-4 py-2 text-sm font-medium"
      >
        {isLoading ? (
          <>
            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
            Загрузка...
          </>
        ) : (
          <>
            <RefreshCw className="mr-2 h-4 w-4" />
            Обновить
          </>
        )}
      </Button>
    </div>
  );
}
