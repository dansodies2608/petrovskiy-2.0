interface LoadingOverlayProps {
  isVisible: boolean;
}

export function LoadingOverlay({ isVisible }: LoadingOverlayProps) {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-white bg-opacity-75 z-50 flex items-center justify-center">
      <div className="flex flex-col items-center space-y-4">
        <div className="loading-spinner h-12 w-12"></div>
        <p className="text-gray-600 font-medium">Загрузка данных...</p>
      </div>
    </div>
  );
}
