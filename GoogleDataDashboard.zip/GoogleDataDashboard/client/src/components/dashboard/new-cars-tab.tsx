import { LocationCard } from './location-card';
import { processSalesData, calculateLocationMetrics, sortLocationsByPriority } from '@/lib/dashboard-utils';
import type { DashboardData } from '@/types/dashboard';

interface NewCarsTabProps {
  data: DashboardData;
}

export function NewCarsTab({ data }: NewCarsTabProps) {
  if (!data.newCars) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Нет данных для отображения</p>
      </div>
    );
  }

  const processedData = processSalesData(
    data.newCars.currentData,
    data.newCars.prevData,
    data.newCars.prevYearData,
    data.newCars.plans
  );

  const sortedLocations = sortLocationsByPriority(processedData);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
      {sortedLocations.map(([locationName, locationData]) => {
        const metrics = calculateLocationMetrics(locationData);
        return (
          <LocationCard
            key={locationName}
            locationName={locationName}
            metrics={metrics}
            type="new"
          />
        );
      })}
    </div>
  );
}
