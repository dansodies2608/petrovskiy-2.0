import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LocationCard } from './location-card';
import { 
  processSalesData, 
  calculateLocationMetrics, 
  calculateAggregatedASPData, 
  formatNumber, 
  formatCurrency, 
  calculateDeviation,
  formatDeviation,
  getDeviationClass,
  sortLocationsByPriority
} from '@/lib/dashboard-utils';
import type { DashboardData } from '@/types/dashboard';

interface UsedCarsTabProps {
  data: DashboardData;
}

export function UsedCarsTab({ data }: UsedCarsTabProps) {
  if (!data.usedCars) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Нет данных для отображения</p>
      </div>
    );
  }

  const processedData = processSalesData(
    data.usedCars.currentData,
    data.usedCars.prevData,
    data.usedCars.prevYearData,
    data.usedCars.plans
  );

  let aggregatedASPData = null;
  if (data.usedCars.aspData) {
    aggregatedASPData = calculateAggregatedASPData(data.usedCars.aspData);
  }

  const sortedLocations = sortLocationsByPriority(processedData);

  return (
    <div className="space-y-6">
      {/* Location Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {sortedLocations.map(([locationName, locationData]) => {
          // Get ASP data for this location
          const aspLocationData = data.usedCars?.aspData?.[locationName];
          let enhancedMetrics = calculateLocationMetrics(locationData);

          // Add ASP specific data if available
          if (aspLocationData) {
            let totalSum = 0;
            let totalFact = 0;
            let totalPlan = 0;

            Object.values(aspLocationData).forEach((aspItem: any) => {
              if (aspItem && typeof aspItem === 'object') {
                totalSum += aspItem.sum || 0;
                totalFact += aspItem.fact || 0;
                totalPlan += aspItem.plan || 0;
              }
            });

            enhancedMetrics = {
              ...enhancedMetrics,
              plan: totalPlan,
              fact: totalFact,
              deviation: totalPlan > 0 ? ((totalFact - totalPlan) / totalPlan) * 100 : 0,
              totalJOK: totalSum,
              jokPerUnit: totalFact > 0 ? totalSum / totalFact : 0,
              dynamics: {
                current: totalFact,
                previous: enhancedMetrics.dynamics.previous,
                previousYear: enhancedMetrics.dynamics.previousYear
              }
            };
          }

          return (
            <LocationCard
              key={locationName}
              locationName={`${locationName} - АСП`}
              metrics={enhancedMetrics}
              type="used"
            />
          );
        })}
      </div>

      {/* ASP Summary */}
      {aggregatedASPData && (
        <Card className="border border-gray-100">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Сводные данные по приему
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {Object.entries(aggregatedASPData).map(([type, typeData]: [string, any]) => {
                const deviation = calculateDeviation(typeData.plan, typeData.fact);
                const avgPrice = typeData.fact ? typeData.sum / typeData.fact : 0;

                return (
                  <Card key={type} className="bg-gray-50">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium">{type}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-600">План</span>
                        <span className="font-semibold">{typeData.plan} шт</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-600">Факт</span>
                        <span className="font-semibold">{typeData.fact} шт</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-600">Отклонение</span>
                        <Badge 
                          variant={deviation >= 0 ? "default" : "destructive"}
                          className={`text-xs ${getDeviationClass(deviation)}`}
                        >
                          {formatDeviation(deviation)}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-600">Сумма</span>
                        <span className="font-semibold">{formatCurrency(typeData.sum)}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-600">Средняя цена</span>
                        <span className="font-semibold">{formatCurrency(avgPrice)}</span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}