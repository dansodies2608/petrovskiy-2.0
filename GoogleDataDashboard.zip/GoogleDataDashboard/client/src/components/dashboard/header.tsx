import { getMonthName } from '@/lib/dashboard-utils';
import { DateSelector } from './date-selector';
import { useAuth } from '@/hooks/use-auth';
import { BarChart3, LogOut, Settings } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  selectedMonth: number;
  selectedYear: number;
  onDateChange: (month: number, year: number) => void;
  isLoading: boolean;
}

export function Header({ selectedMonth, selectedYear, onDateChange, isLoading }: HeaderProps) {
  const { logout, user } = useAuth();
  const periodText = `${getMonthName(selectedMonth)} ${selectedYear}`;

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center">
              <BarChart3 className="text-white text-lg" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">{periodText}</h1>
              <p className="text-sm text-gray-500">Автомобильная аналитика</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <DateSelector 
              selectedMonth={selectedMonth}
              selectedYear={selectedYear}
              onDateChange={onDateChange}
              isLoading={isLoading}
            />
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">{user?.email}</span>
              {user?.role === 'admin' && (
                <Link href="/admin">
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4 mr-1" />
                    Администрирование
                  </Button>
                </Link>
              )}
              <Button 
                variant="outline" 
                size="sm" 
                onClick={logout}
                className="flex items-center space-x-1"
              >
                <LogOut className="h-4 w-4" />
                <span>Выход</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
