
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { formatNumber, formatCurrency, formatDeviation, getDeviationClass } from '@/lib/dashboard-utils';
import { cn } from '@/lib/utils';
import type { LocationMetrics } from '@/types/dashboard';

interface LocationCardProps {
  locationName: string;
  metrics: LocationMetrics;
  type: 'new' | 'used';
}

export function LocationCard({ locationName, metrics, type }: LocationCardProps) {
  const totalJOK = metrics.totalJOK || 0;
  const jokPerUnit = metrics.jokPerUnit || 0;
  const avgPrice = jokPerUnit > 0 ? jokPerUnit : 0;

  // Calculate dynamics trends - ensure we have valid numbers
  const currentCount = metrics.dynamics?.current || 0;
  const previousCount = metrics.dynamics?.previous || 0;
  const previousYearCount = metrics.dynamics?.previousYear || 0;
  
  const monthTrend = currentCount - previousCount;
  const yearTrend = currentCount - previousYearCount;
  const monthTrendPercent = previousCount > 0 ? ((monthTrend / previousCount) * 100) : 0;
  const yearTrendPercent = previousYearCount > 0 ? ((yearTrend / previousYearCount) * 100) : 0;

  return (
    <Card className="card-hover border border-gray-200 bg-white">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-gray-900">
          {locationName}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* План/Факт row */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-gray-600 mb-1">План</div>
            <div className="text-lg font-semibold text-gray-900">
              {formatNumber(metrics.plan)} шт
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-600 mb-1">Факт</div>
            <div className="text-lg font-semibold text-gray-900">
              {formatNumber(metrics.fact)} шт
            </div>
          </div>
        </div>

        {/* Откл./ЖОК row */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-gray-600 mb-1">Откл.</div>
            <div className={cn(
              "text-lg font-semibold",
              metrics.deviation >= 0 ? "text-green-600" : "text-red-600"
            )}>
              {formatDeviation(metrics.deviation)}
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-600 mb-1">ЖОК</div>
            <div className="text-lg font-semibold text-gray-900">
              {totalJOK > 0 ? formatCurrency(totalJOK, false) : 'не число ₽'}
            </div>
          </div>
        </div>

        {/* ЖОК/шт */}
        <div>
          <div className="text-sm text-gray-600 mb-1">ЖОК/шт</div>
          <div className="text-lg font-semibold text-gray-900">
            {avgPrice > 0 ? formatCurrency(avgPrice, false) : 'не число ₽'}
          </div>
        </div>

        {/* Динамика продаж */}
        <div className="pt-4 border-t border-gray-200">
          <h4 className="text-base font-semibold text-gray-900 mb-3">Динамика продаж</h4>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-2 text-gray-600 font-medium">Период</th>
                  <th className="text-right py-2 text-gray-600 font-medium">Итого</th>
                  <th className="text-right py-2 text-gray-600 font-medium">Рост</th>
                </tr>
              </thead>
              <tbody className="space-y-1">
                <tr>
                  <td className="py-1 text-gray-700">Текущий</td>
                  <td className="py-1 text-right font-medium">{formatNumber(currentCount)}</td>
                  <td className="py-1 text-right">-</td>
                </tr>
                <tr>
                  <td className="py-1 text-gray-700">Предыдущий</td>
                  <td className="py-1 text-right font-medium">{formatNumber(previousCount)}</td>
                  <td className={cn(
                    "py-1 text-right font-medium",
                    previousCount > 0 ? (monthTrendPercent >= 0 ? "text-green-600" : "text-red-600") : "text-gray-500"
                  )}>
                    {previousCount > 0 ? `${monthTrendPercent >= 0 ? '+' : ''}${monthTrendPercent.toFixed(1)}%` : '-'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1 text-gray-700">АППГ</td>
                  <td className="py-1 text-right font-medium">{formatNumber(previousYearCount)}</td>
                  <td className={cn(
                    "py-1 text-right font-medium",
                    previousYearCount > 0 ? (yearTrendPercent >= 0 ? "text-green-600" : "text-red-600") : "text-gray-500"
                  )}>
                    {previousYearCount > 0 ? `${yearTrendPercent >= 0 ? '+' : ''}${yearTrendPercent.toFixed(1)}%` : '-'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
