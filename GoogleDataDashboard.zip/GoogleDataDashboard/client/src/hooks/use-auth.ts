
import { useState, useEffect } from 'react';
import { useToast } from './use-toast';

interface User {
  id: number;
  email: string;
  role: string;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isLoading: true,
    isAuthenticated: false
  });
  const { toast } = useToast();

  // Check if user is authenticated
  const checkAuth = async () => {
    try {
      const response = await fetch('/api/user', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const user = await response.json();
        setAuthState({
          user,
          isLoading: false,
          isAuthenticated: true
        });
      } else {
        setAuthState({
          user: null,
          isLoading: false,
          isAuthenticated: false
        });
      }
    } catch (error) {
      setAuthState({
        user: null,
        isLoading: false,
        isAuthenticated: false
      });
    }
  };

  // Login function
  const login = async (email: string, password: string) => {
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const user = await response.json();
        setAuthState({
          user,
          isLoading: false,
          isAuthenticated: true
        });
        toast({
          title: "Успешный вход",
          description: "Добро пожаловать!",
        });
        return { success: true };
      } else {
        const error = await response.json();
        toast({
          title: "Ошибка входа",
          description: error.error || "Неверные учетные данные",
          variant: "destructive",
        });
        return { success: false, error: error.error };
      }
    } catch (error) {
      toast({
        title: "Ошибка входа",
        description: "Проблема с подключением к серверу",
        variant: "destructive",
      });
      return { success: false, error: "Проблема с подключением" };
    }
  };

  // Logout function
  const logout = async () => {
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include',
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
    
    setAuthState({
      user: null,
      isLoading: false,
      isAuthenticated: false
    });
    
    toast({
      title: "Выход выполнен",
      description: "До свидания!",
    });
  };

  // Check admin exists
  const checkAdminExists = async () => {
    try {
      const response = await fetch('/api/admin-exists');
      if (response.ok) {
        const data = await response.json();
        return data.hasAdmin;
      }
    } catch (error) {
      console.error('Error checking admin:', error);
    }
    return true;
  };

  // Register admin
  const registerAdmin = async (email: string, password: string) => {
    try {
      const response = await fetch('/api/register-admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const user = await response.json();
        setAuthState({
          user,
          isLoading: false,
          isAuthenticated: true
        });
        toast({
          title: "Администратор создан",
          description: "Добро пожаловать!",
        });
        return { success: true };
      } else {
        const error = await response.json();
        toast({
          title: "Ошибка создания администратора",
          description: error.error,
          variant: "destructive",
        });
        return { success: false, error: error.error };
      }
    } catch (error) {
      toast({
        title: "Ошибка создания администратора",
        description: "Проблема с подключением к серверу",
        variant: "destructive",
      });
      return { success: false, error: "Проблема с подключением" };
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return {
    ...authState,
    login,
    logout,
    checkAuth,
    checkAdminExists,
    registerAdmin
  };
}
