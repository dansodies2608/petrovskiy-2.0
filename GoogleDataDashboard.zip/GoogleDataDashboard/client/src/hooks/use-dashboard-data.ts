import { useQuery } from '@tanstack/react-query';
import { fetchDashboardData } from '@/lib/api';
import type { DashboardData } from '@/types/dashboard';

export function useDashboardData(month: number, year: number) {
  return useQuery<DashboardData>({
    queryKey: ['/api/dashboard', month, year],
    queryFn: () => fetchDashboardData(month, year),
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
    refetchOnWindowFocus: false
  });
}
