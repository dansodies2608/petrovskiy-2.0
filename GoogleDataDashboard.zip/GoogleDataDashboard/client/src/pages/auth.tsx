
import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { LoginForm } from '@/components/auth/login-form';
import { AdminSetup } from '@/components/auth/admin-setup';
import { Loader2 } from 'lucide-react';

export default function Auth() {
  const { login, registerAdmin, isLoading } = useAuth();
  const [hasAdmin, setHasAdmin] = useState<boolean | null>(null);
  const [isCheckingAdmin, setIsCheckingAdmin] = useState(true);

  useEffect(() => {
    const checkAdmin = async () => {
      try {
        const response = await fetch('/api/admin-exists');
        if (response.ok) {
          const data = await response.json();
          setHasAdmin(data.hasAdmin);
        }
      } catch (error) {
        console.error('Error checking admin:', error);
        setHasAdmin(true); // Assume admin exists on error
      } finally {
        setIsCheckingAdmin(false);
      }
    };

    checkAdmin();
  }, []);

  if (isCheckingAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (hasAdmin === false) {
    return (
      <AdminSetup 
        onRegisterAdmin={registerAdmin}
        isLoading={isLoading}
      />
    );
  }

  return (
    <LoginForm 
      onLogin={login}
      isLoading={isLoading}
    />
  );
}
