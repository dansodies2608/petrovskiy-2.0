import { useState } from 'react';
import { useDashboardData } from '@/hooks/use-dashboard-data';
import { useToast } from '@/hooks/use-toast';
import { Header } from '@/components/dashboard/header';
import { BottomNavigation } from '@/components/dashboard/bottom-navigation';
import { LoadingOverlay } from '@/components/dashboard/loading-overlay';
import { NewCarsTab } from '@/components/dashboard/new-cars-tab';
import { UsedCarsTab } from '@/components/dashboard/used-cars-tab';
import { ServiceTab } from '@/components/dashboard/service-tab';
import { MKCTab } from '@/components/dashboard/mkc-tab';
import { BalanceTab } from '@/components/dashboard/balance-tab';
import type { TabType } from '@/types/dashboard';

export default function Dashboard() {
  const { toast } = useToast();
  
  // State management
  const today = new Date();
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(today.getFullYear());
  const [activeTab, setActiveTab] = useState<TabType>('new-cars');
  
  // Data fetching
  const { data, isLoading, error, refetch } = useDashboardData(selectedMonth, selectedYear);

  // Handle date changes
  const handleDateChange = (month: number, year: number) => {
    setSelectedMonth(month);
    setSelectedYear(year);
    refetch().then(() => {
      toast({
        title: "Данные обновлены",
        description: "Данные успешно загружены",
      });
    }).catch((error) => {
      toast({
        title: "Ошибка загрузки",
        description: error.message || "Не удалось загрузить данные",
        variant: "destructive",
      });
    });
  };

  // Handle tab changes
  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    // Smooth scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Show error state
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Ошибка загрузки данных</h2>
          <p className="text-gray-500 mb-4">{error.message}</p>
          <button 
            onClick={() => refetch()}
            className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg"
          >
            Попробовать снова
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <LoadingOverlay isVisible={isLoading} />
      
      <Header 
        selectedMonth={selectedMonth}
        selectedYear={selectedYear}
        onDateChange={handleDateChange}
        isLoading={isLoading}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20">
        {data && (
          <div className="space-y-6">
            {activeTab === 'new-cars' && <NewCarsTab data={data} />}
            {activeTab === 'used-cars' && <UsedCarsTab data={data} />}
            {activeTab === 'service' && <ServiceTab data={data} />}
            {activeTab === 'mkc' && <MKCTab data={data} />}
            {activeTab === 'balance' && <BalanceTab data={data} />}
          </div>
        )}
      </main>

      <BottomNavigation 
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />
    </div>
  );
}
